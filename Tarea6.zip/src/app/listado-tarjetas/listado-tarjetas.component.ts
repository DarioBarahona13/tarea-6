import { Component, OnInit } from '@angular/core';
import { Idetalles } from '../tarjetas/Idetalles';

@Component({
  selector: 'app-listado-tarjetas',
  templateUrl: './listado-tarjetas.component.html',
  styleUrls: ['./listado-tarjetas.component.css']
})
export class ListadoTarjetasComponent implements OnInit {
  listadoDetalles: Idetalles[] = [{
tag:"Tecnology",
titulo:"What's new in 2022 Tech",
descripcion:"Lorem ipsum dolor sit amet consectetur adipisicing elit.",
nombre:"Dario",
  },
  {
tag:"Science",
titulo:"What's new in 2022 Tech",
descripcion:"Lorem ipsum dolor sit amet consectetur adipisicing elit.",
nombre:"Oscar",
  }
]
  constructor() { }

  ngOnInit(): void {
  }

}
