import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { TarjetasComponent } from './tarjetas/tarjetas.component';
import { ListadoTarjetasComponent } from './listado-tarjetas/listado-tarjetas.component';

@NgModule({
  declarations: [
    AppComponent,
    TarjetasComponent,
    ListadoTarjetasComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
