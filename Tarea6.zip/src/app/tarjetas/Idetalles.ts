export interface Idetalles {
tag:string
titulo:string
descripcion:string
nombre:string
}