import { Component, OnInit,Input } from '@angular/core';
import { Idetalles } from './Idetalles';

@Component({
  selector: 'app-tarjetas',
  templateUrl: './tarjetas.component.html',
  styleUrls: ['./tarjetas.component.css']
})
export class TarjetasComponent implements OnInit {
@Input() detalle?: Idetalles = {
tag:"Tecnology",
titulo:"What's new in 2022 Tech",
descripcion:"Lorem ipsum dolor sit amet consectetur adipisicing elit.",
nombre:"Dario",
}


  constructor() { }

  ngOnInit(): void {
  }

}
